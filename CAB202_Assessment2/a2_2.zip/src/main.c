#include <avr/io.h>
#include <stdio.h>
#include <stdint.h>

#include "uart.h"
#include "timer.h"
#include "spi.h"
#include "pwm.h"

#define MIN_DELAY_MS 250
#define MAX_DELAY_MS 2000

// 1 Gameplay (5 marks)
// Code your own serial_init
// Code button press reading
// Code 7-segment display operation
// Code Input validation for game

// 2 Sequence and Playback (9 marks)
// Sequence generation (look at last assignment 2)
// Playback delay, read from potentiometer
// Playback frequency

// 3 Commands (6 marks)
// Implement 1 through UART commands

// Week 7 - Interupts
// Week 9 - Timers and PWM
// Week 10 - UART
// Week 11 - Buttons

// 10111110(0xBE) S1 lhs
// 11101011(0xEB) S2 lhs
// 00111110(0x3E) S3 rhs
// 01101011(0x6B) S3 rhs

volatile uint8_t simon_display [] = {0xBE, 0xEB, 0x3E, 0x6B};
uint16_t simon_freq [] = {345, 290, 461, 173};
uint32_t MASK = 0xE2023CAB;
uint32_t STATE_LFSR = 0x11275561;
uint8_t sequence_length = 1;

uint8_t simon_state = 0;
uint8_t buzzer_state = 0;
uint16_t per_value = 0;
uint16_t cmp_value = 0;
uint32_t static counter = 0;
uint32_t playback_delay;

void buttons_init() {
    // Enable pull-up resistors for PBs
    PORTA.PIN4CTRL = PORT_PULLUPEN_bm;
    PORTA.PIN5CTRL = PORT_PULLUPEN_bm;
    PORTA.PIN6CTRL = PORT_PULLUPEN_bm;
    PORTA.PIN7CTRL = PORT_PULLUPEN_bm;
}

// Playback init
void adc_init(void) {
    ADC0.CTRLA = ADC_ENABLE_bm;
    ADC0.CTRLB = ADC_PRESC_DIV2_gc;
    ADC0.CTRLC = (4 << ADC_TIMEBASE_gp) | ADC_REFSEL_VDD_gc;
    ADC0.CTRLE = 64;
    ADC0.CTRLF = ADC_FREERUN_bm;
    ADC0.MUXPOS = ADC_MUXPOS_AIN2_gc;
    ADC0.COMMAND = ADC_MODE_SINGLE_8BIT_gc | ADC_START_IMMEDIATE_gc;
}


// Section B
uint32_t STEP;
void stepGeneration(uint32_t* STATE, uint32_t* STEP){
    uint32_t BIT;
    BIT = *STATE & 0x01;
    *STATE = *STATE >> 1;
    if (BIT == 1) {
        *STATE = *STATE ^ MASK;
    }
    *STEP = *STATE & 0b11;
    //STATE_LFSR = STATE;
}

// Play Whole Sequence
uint8_t stepContinue = 0;
void nextStep(uint8_t *sequence_length){
    char step_str[1];
    sprintf(step_str, "%d", *sequence_length);
    uart_puts(step_str);
    uart_puts(" ");
    uint32_t STATE = STATE_LFSR;
    uint8_t step_state = 0;
    uint8_t sequence_step = 0;
    while (sequence_step < *sequence_length){
        switch (step_state)
        {
            case(0):
                stepGeneration(&STATE, &STEP);
                stepContinue = 1;
                step_state = 1;
                break;
            case(1):
                if (STEP == 00){
                    simon_state = 1;
                    gameplayCases();
                }
                else if (STEP == 01){
                    simon_state = 2;
                    gameplayCases();
                }
                else if (STEP == 02){
                    simon_state = 3;
                    gameplayCases();
                }
                else if (STEP == 03){
                    simon_state = 4;
                    gameplayCases();
                }
                char step_str[2];
                sprintf(step_str, "%02X", STEP);
                uart_puts(step_str);
                uart_puts(" ");
                step_state = 2;
                break;
            case(2):
                if (stepContinue == 0) {
                    sequence_step += 1;
                    step_state = 0;
                }
                else{
                    step_state = 2;
                }
                break;
            default:
                break;
            }
    }
}

// CHECK USER INPUT

// Section D
//61
void freqCalculate(uint16_t freq, uint16_t* per_value, uint16_t* cmp_value){
    float f_freq = freq;
    float f_time = 300 * 0.000000001f;
    float f_result = f_freq * f_time;
    *per_value = 1.0f / f_result;
    *cmp_value = *per_value; //* 0.5f
}

// Playback Delay
void delayPlayback(uint8_t potValue) {
    float delayFactor = (float)potValue / 255.0;
    playback_delay = (uint16_t)(MIN_DELAY_MS + delayFactor * (MAX_DELAY_MS - MIN_DELAY_MS));
}

uint8_t result;
ISR(TCB0_INT_vect) {
    result = ADC0.RESULT;
    delayPlayback(result);
    counter++;
    switch (buzzer_state) {
    case (0):
        TCA0.SINGLE.CMP0BUF = per_value;
        if (counter > playback_delay){
            counter = 0;
            buzzer_state = 0;
            stepContinue = 0;
        }
        else{
            stepContinue = 1;
        }
        break;
    case (1):
        if (counter > (playback_delay * 0.5)) {//Playback_delay / 2
            counter = 0;
            simon_state = 0;
            gameplayCases();
        }
        else{
            TCA0.SINGLE.PERBUF = per_value;
            TCA0.SINGLE.CMP0BUF = per_value >> 1;
        }
        break;
    default:
        break;
    }
    TCB0.INTFLAGS = TCB_CAPT_bm;
}

// Section A
void gameplayCases(void){
    switch (simon_state)
    {
    case (0):
        spi_write(0xFF);
        counter = 0;
        buzzer_state = 0;
        break;
    case (1):
        //E(High) = 345
        spi_write(simon_display[0]);
        freqCalculate(simon_freq[0], &per_value, &cmp_value);
        counter = 0;
        buzzer_state = 1;
        break;
    case (2):
        //C# = 290
        spi_write(simon_display[1]);
        freqCalculate(simon_freq[1], &per_value, &cmp_value);
        counter = 0;
        buzzer_state = 1;
        break;
    case (3):
        //A = 461
        spi_write(simon_display[2]);
        freqCalculate(simon_freq[2], &per_value, &cmp_value);
        counter = 0;
        buzzer_state = 1;
        break;
    case (4):
        //E(Low) = 173
        spi_write(simon_display[3]);
        freqCalculate(simon_freq[3], &per_value, &cmp_value);
        counter = 0;
        buzzer_state = 1;
        break;
    default:
        simon_state = 0;
        break;
    }
}

uint8_t game_state = 0;
int main(void) {
    cli();
    adc_init();
    uart_init();
    spi_init();
    pwm_init();
    buttons_init();

    uint8_t pb_sample = 0xFF;
    uint8_t pb_sample_r = 0xFF;
    uint8_t pb_changed, pb_rising, pb_falling;
    //loop forever until lose
    //play sequence
    //create a switch statement for playing sequence and user input
    
    while (1) {
        timer_init();
        
        pb_sample_r = pb_sample;
        pb_sample = PORTA.IN;
        pb_changed = pb_sample ^ pb_sample_r;

        pb_falling = pb_changed & pb_sample_r;
        pb_rising = pb_changed & pb_sample;

        switch (game_state)
        {
        case(0):
            //stepContinue = 0; // REMOVE
            nextStep(&sequence_length);
            sequence_length += 1;
            stepContinue = 1;
            game_state = 1;
            break;
        case(1):
            if (pb_falling & PIN4_bm) {
                // REMOVE
                //char step_str[0];
                //sprintf(step_str, "%d", playback_delay);
                //uart_puts(step_str);
                //uart_puts(" ");
                simon_state = 1;
                game_state = 2;
                gameplayCases();
            }
            else if (pb_falling & PIN5_bm) {
                simon_state = 2;
                game_state = 2;
                gameplayCases();
            }
            else if (pb_falling & PIN6_bm) {
                simon_state = 3;
                game_state = 2;
                gameplayCases();
            }
            else if (pb_falling & PIN7_bm) {
                simon_state = 4;
                game_state = 2;
                gameplayCases();
            }
            break;
        case(2):
            // if statement detecting if user has done same amount of inputs for sequence length
            if (stepContinue == 0){
                game_state = 0;
            }
            break;
        default:
            game_state = 0;
            break;
        }
    }
    
    sei();
}

// CAN PRESS WHEN EVER
ISR(USART0_RXC_vect) {
    uint8_t freq_range = 0;
    char rx = USART0.RXDATAL;
    switch (rx) {
        case '1':
        case 'q':
            simon_state = 1;
            game_state = 2;
            gameplayCases();
            break;
        case '2':
        case 'w':
            simon_state = 2;
            game_state = 2;
            gameplayCases();
            break;
        case '3':
        case 'e':
            simon_state = 3;
            game_state = 2;
            gameplayCases();
            break;
        case '4':
        case 'r':
            simon_state = 4;
            game_state = 2;
            gameplayCases();
            break;
        case ',':
        case 'k':
        // <<= same as *
        // DO IT THE WAY THEY WANT (follow example)
        // modify freqcalc so o.5f is the octive you shift (change to a variable)
        // OCTIVE IS THE SHIFT (0.5) IN CMP?
            for (int freq = 0; freq < 4; freq++){
                if ((simon_freq[freq] * 2) > 20000){
                    freq_range = 1;
                }
            }
            if (freq_range == 0){
                for (int freq = 0; freq < 4; freq++){
                    simon_freq[freq] <<= 1;
                }
            }
            freq_range = 0;
            //simon_state = 0;
            //game_state = 1;
            //gameplayCases();
            char step_str[0];
            sprintf(step_str, "%d", simon_freq[2]);
            uart_puts(step_str);
            uart_puts(" ");
            break;
        case '.':
        case 'l':
            for (int freq = 0; freq < 4; freq++){
                if ((simon_freq[freq] / 2) < 20){
                    freq_range = 1;
                }
            }
            if (freq_range == 0){
                for (int freq = 0; freq < 4; freq++){
                    simon_freq[freq] >>= 1;
                }
            }
            freq_range = 0;
            //simon_state = 0;
            //game_state = 1;
            //gameplayCases();
            sprintf(step_str, "%d", simon_freq[2]);
            uart_puts(step_str);
            uart_puts(" ");
            break;
        default:
            game_state = 0;
            break;
    }
}

/*
void new_freq(uint8_t freq_change){
    uint16_t new_freqs[3];
    uint8_t freq_range = 0;
    for (int freq = 0; freq < sizeof(simon_freq); freq++) {
        new_freqs[freq] = simon_freq[freq];
    }
    for (int freq = 0; freq < sizeof(new_freqs); freq++){
        if (freq_change == 0){
            new_freqs[freq] *= 2;
        }
        else{
            new_freqs[freq] /= 2;
        }
        if (new_freqs[freq] > 20000 || new_freqs[freq] < 20){
            freq_range = 1;
        }
    }
    if (freq_range == 0){
        for (int freq = 0; freq < sizeof(simon_freq); freq++) {
            simon_freq[freq] = new_freqs[freq];
        }
    }
    char step_str[0];
    sprintf(step_str, "%d", simon_freq[1]);
    uart_puts(step_str);
    uart_puts(" ");
}
*/

/*
GO THROUGH DISCORD CHAT!!
#include <stdbool.h>
#include <stdio.h>

int uart_putc_printf(char c, FILE *stream)
{
    uart_putc(c);
    return 0;
}

static FILE mystdout = FDEV_SETUP_STREAM(uart_putc_printf, NULL, _FDEV_SETUP_WRITE);

// When the program starts
stdout = &mystdout;
*/